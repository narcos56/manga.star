import Image from 'next/image'
import Link from 'next/link'

interface MangaCardProps {
  id: string
  title: string
  cover: string
  author: string
}

const MangaCard: React.FC<MangaCardProps> = ({ id, title, cover, author }) => {
  return (
    <Link href={`/manga/${id}`} className="block">
      <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
        <Image src={cover || "/placeholder.svg"} alt={title} width={200} height={300} className="w-full h-64 object-cover" />
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{author}</p>
        </div>
      </div>
    </Link>
  )
}

export default MangaCard

