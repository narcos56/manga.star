import Link from 'next/link'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronDown } from 'lucide-react'

const Header = () => {
  return (
    <header className="bg-gray-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">Manga star</Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <DropdownMenu>
                <DropdownMenuTrigger className="hover:text-gray-300 flex items-center">
                  الرئيسية <ChevronDown className="ml-1 h-4 w-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>
                    <Link href="/" className="w-full">الصفحة الرئيسية</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/about" className="w-full">عن الموقع</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/contact" className="w-full">اتصل بنا</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </li>
            <li><Link href="/browse" className="hover:text-gray-300">تصفح المانجا</Link></li>
            <li><Link href="/latest" className="hover:text-gray-300">أحدث الإصدارات</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  )
}

export default Header

