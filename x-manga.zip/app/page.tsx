import Header from '../components/Header'
import MangaCard from '../components/MangaCard'

const mangaList = [
  { id: '1', title: 'عنوان المانجا 1', cover: '/placeholder.svg', author: 'المؤلف 1' },
  { id: '2', title: 'عنوان المانجا 2', cover: '/placeholder.svg', author: 'المؤلف 2' },
  { id: '3', title: 'عنوان المانجا 3', cover: '/placeholder.svg', author: 'المؤلف 3' },
  // يمكنك إضافة المزيد من المانجا هنا
]

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">اهلا بك في عالم مانجا ستار</h1>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {mangaList.map((manga) => (
            <MangaCard key={manga.id} {...manga} />
          ))}
        </div>
      </main>
    </div>
  )
}

