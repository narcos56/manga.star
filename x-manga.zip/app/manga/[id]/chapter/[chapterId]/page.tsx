import Header from '../../../../../components/Header'
import Image from 'next/image'
import Link from 'next/link'

const chapterPages = [
  '/placeholder.svg',
  '/placeholder.svg',
  '/placeholder.svg',
  // يمكنك إضافة المزيد من الصفحات هنا
]

export default function ChapterReader({ params }: { params: { id: string, chapterId: string } }) {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">الفصل {params.chapterId}</h1>
        <div className="space-y-4">
          {chapterPages.map((page, index) => (
            <div key={index} className="flex justify-center">
              <Image src={page || "/placeholder.svg"} alt={`الصفحة ${index + 1}`} width={800} height={1200} className="max-w-full h-auto" />
            </div>
          ))}
        </div>
        <div className="mt-6 flex justify-between">
          <Link href={`/manga/${params.id}/chapter/${Number(params.chapterId) - 1}`} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
            الفصل السابق
          </Link>
          <Link href={`/manga/${params.id}/chapter/${Number(params.chapterId) + 1}`} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
            الفصل التالي
          </Link>
        </div>
      </main>
    </div>
  )
}

