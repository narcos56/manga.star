import Header from '../../../components/Header'
import Link from 'next/link'
import Image from 'next/image'

const mangaDetails = {
  id: '1',
  title: 'عنوان المانجا',
  cover: '/placeholder.svg',
  author: 'المؤلف',
  description: 'وصف المانجا يظهر هنا. يمكنك إضافة المزيد من التفاصيل حول قصة المانجا وشخصياتها.',
  chapters: [
    { id: '1', title: 'الفصل 1' },
    { id: '2', title: 'الفصل 2' },
    { id: '3', title: 'الفصل 3' },
  ]
}

export default function MangaDetails({ params }: { params: { id: string } }) {
  // في التطبيق الحقيقي، ستقوم بجلب تفاصيل المانجا باستخدام الـ ID
  const manga = mangaDetails

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row">
            <Image src={manga.cover || "/placeholder.svg"} alt={manga.title} width={300} height={450} className="rounded-lg mb-4 md:mb-0 md:mr-6" />
            <div>
              <h1 className="text-3xl font-bold mb-2">{manga.title}</h1>
              <p className="text-gray-600 mb-4">المؤلف: {manga.author}</p>
              <p className="mb-4">{manga.description}</p>
              <h2 className="text-2xl font-semibold mb-2">الفصول</h2>
              <ul className="space-y-2">
                {manga.chapters.map((chapter) => (
                  <li key={chapter.id}>
                    <Link href={`/manga/${manga.id}/chapter/${chapter.id}`} className="text-blue-600 hover:underline">
                      {chapter.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

